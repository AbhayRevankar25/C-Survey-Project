import ply.lex as lex

tokens = (
    'BREAK',
    'SWITCH',
    'CASE',
    'DEFAULT',
    'SEMI',
    'SOP',
    'RETURNTYPE',
    'DQUOTE',
    'IDENTIFIER',
    'NUMBER',
    'LPAREN',
    'RPAREN',
    'LBRACE',
    'RBRACE',
    'ASSIGN',
    'PLUS',
    'MINUS',
    'TIMES',
    'DIVIDE',
    'SEMICOLON'
)

t_NUMBER = r'\d+(\.\d+)?'
t_IDENTIFIER = r'[a-zA-Z_][a-zA-Z0-9_]*'
t_DQUOTE = r'"'
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_LBRACE = r'\{'
t_RBRACE = r'\}'
t_ASSIGN = r'='
t_PLUS = r'\+'
t_MINUS = r'-'
t_TIMES = r'\*'
t_DIVIDE = r'/'
t_SEMICOLON = r';'

t_ignore = ' \t'

def t_CASE(t):
    r'case'
    return t

def t_DEFAULT(t):
    r'default'
    return t

def t_SOP(t):
    r'System\.out\.println'
    return t

def t_SEMI(t):
    r':'
    return t

def t_BREAK(t):
    r'break'
    return t

def t_SWITCH(t):
    r'switch'
    return t

def t_RETURNTYPE(t):
    r'float|int|char'
    return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

def t_error(t):
    print("Illegal character '%s'" % t.value[0])
    t.lexer.skip(1)

# Build the lexer
lexer = lex.lex()

# Test the lexer with some input
input_text = '''
switch(choice){
    case 1:
    System.out.println("1");
    break;
    case 2:
    System.out.println("2");
    break;
    default:
    System.out.println("Invalid input");
}
'''

# Give the lexer some input
lexer.input(input_text)

# Tokenize
while True:
    tok = lexer.token()
    if not tok:
        break  # No more input
    print(tok)