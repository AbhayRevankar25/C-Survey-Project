import ply.lex as lex

tokens = (
    'LOGICAL',
    'WHILE',
    'SOP',
    'RETURNTYPE',
    'DQUOTE',
    'IDENTIFIER',
    'NUMBER',
    'LPAREN',
    'RPAREN',
    'LBRACE',
    'RBRACE',
    'ASSIGN',
    'PLUS',
    'MINUS',
    'TIMES',
    'DIVIDE',
    'SEMICOLON'
)

t_NUMBER = r'\d+(\.\d+)?'
t_IDENTIFIER = r'[a-zA-Z_][a-zA-Z0-9_]*'
t_DQUOTE = r'"'
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_LBRACE = r'\{'
t_RBRACE = r'\}'
t_ASSIGN = r'='
t_PLUS = r'\+'
t_MINUS = r'-'
t_TIMES = r'\*'
t_DIVIDE = r'/'
t_SEMICOLON = r';'

t_ignore = ' \t'

def t_SOP(t):
    r'System\.out\.println'
    return t

def t_WHILE(t):
    r'while'
    return t

def t_LOGICAL(t):
    r'\&\&|\|\||\!|\&|\||\<=|\>='
    return t

def t_RETURNTYPE(t):
    r'float|int|char'
    return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

def t_error(t):
    print("Illegal character '%s'" % t.value[0])
    t.lexer.skip(1)

# Build the lexer
lexer = lex.lex()

# Test the lexer with some input
input_text = '''
while(i>=8 && i<=12){
    System.out.println("True");
    i=i+1;
}
'''

# Give the lexer some input
lexer.input(input_text)

# Tokenize
while True:
    tok = lexer.token()
    if not tok:
        break  # No more input
    print(tok)
