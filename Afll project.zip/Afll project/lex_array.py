import ply.lex as lex

tokens = (
    'TYPE',
    'IDENTIFIER',
    'NUMBER',
    'CHAR',
    'LPAREN',
    'RPAREN',
    'LBRACE',
    'RBRACE',
    'COMMA',
    'ASSIGN',
    'SEMICOLON'
)

t_NUMBER = r'\d+(\.\d+)?'
t_CHAR = r'[a-zA-Z0-9]'
t_IDENTIFIER = r'[a-zA-Z_][a-zA-Z0-9_]*'
t_LPAREN = r'\['
t_RPAREN = r'\]'
t_LBRACE = r'\{'
t_RBRACE = r'\}'
t_COMMA = r','
t_ASSIGN = r'='
t_SEMICOLON = r';'

t_ignore = ' \t'

def t_TYPE(t):
    r'float|int|char'
    return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

def t_error(t):
    print("Illegal character '%s'" % t.value[0])
    t.lexer.skip(1)

# Build the lexer
lexer = lex.lex()

# Test the lexer with some input
input_text = '''
    int[] arr = {1,3,5,7,9};
'''

# Give the lexer some input
lexer.input(input_text)

# Tokenize
while True:
    tok = lexer.token()
    if not tok:
        break  # No more input
    print(tok)