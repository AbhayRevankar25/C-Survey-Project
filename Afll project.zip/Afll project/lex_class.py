import ply.lex as lex

tokens = (
    'RETURN',
    'THIS',
    'CLASS',
    'ACCESS',
    'RETURNTYPE',
    'SOP',
    'DQUOTE',
    'IDENTIFIER',
    'NUMBER',
    'LPAREN',
    'RPAREN',
    'LBRACE',
    'RBRACE',
    'COMMA',
    'ASSIGN',
    'PLUS',
    'MINUS',
    'TIMES',
    'DIVIDE',
    'SEMICOLON'
)

t_NUMBER = r'\d+(\.\d+)?'
t_IDENTIFIER = r'[a-zA-Z_][a-zA-Z0-9_]*'
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_LBRACE = r'\{'
t_RBRACE = r'\}'
t_COMMA = r','
t_DQUOTE = r'"'
t_ASSIGN = r'='
t_PLUS = r'\+'
t_MINUS = r'-'
t_TIMES = r'\*'
t_DIVIDE = r'/'
t_SEMICOLON = r';'

# Ignored characters (spaces and tabs)
t_ignore = ' \t'

def t_ACCESS(t):
    r'public|private|protected'
    return t

def t_THIS(t):
    r'this\.'
    return t

def t_RETURN(t):
    r'return'
    return t

def t_CLASS(t):
    r'class'
    return t

def t_RETURNTYPE(t):
    r'double|float|void|int|char|String'
    return t

def t_SOP(t):
    r'System\.out\.println'
    return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

def t_error(t):
    print("Illegal character '%s'" % t.value[0])
    t.lexer.skip(1)

lexer = lex.lex()

input_text = '''
    public class Car{
        private:
            int year;
            double price;
        public:
            Car(String brand, int year, double price) {
                this.brand = brand;
                this.year = year;
                this.price = price;
            }
            String getBrand() {
                return brand;
            }
            int getYear() {
                return year;
            }
            double getPrice() {
                return price;
            }
            void setPrice(double price) {
                this.price = price;
            }
    }    
'''

lexer.input(input_text)

while True:
    tok = lexer.token()
    if not tok:
        break  # No more input
    print(tok)