import ply.yacc as yacc

from lex_class import tokens

def p_class(p):
    '''class : ACCESS CLASS IDENTIFIER LBRACE stats RBRACE'''
    p[0] = p[1] + 'class' + p[3] + '{' + p[5] + '}'
    pass
def p_stats(p):
    '''stats : stat
             | stat stats'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = p[1] + p[2]

def p_stat(p):
    '''stat : ACCESS assignment_statement
            | ACCESS function
            | ACCESS constructor'''
    p[0] = p[1] + p[2]

def p_constructor(p):
    '''constructor : IDENTIFIER LPAREN parameters RPAREN LBRACE statements RBRACE'''
    p[0] = p[1] + '(' + p[3] + ')' + '{' + p[6] + '}'

def p_function(p):
    '''function : RETURNTYPE IDENTIFIER LPAREN parameters RPAREN LBRACE statements RBRACE
                | RETURNTYPE IDENTIFIER LPAREN RPAREN LBRACE statements RBRACE'''
    if len(p) == 8:
        p[0] = p[1] + p[2] + '(' + p[4] + ')' + '{' + p[7] + '}'
    else:
        p[0] = p[1] + p[2] + '()' + '{' + p[6] + '}'

def p_parameters(p):
    '''parameters : parameter
                  | parameter COMMA parameters'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = p[1] + ',' + p[3]

def p_parameter(p):
    '''parameter : RETURNTYPE IDENTIFIER'''
    p[0] = p[1] + p[2]

def p_statements(p):
    '''statements : statement
                  | statement statements'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = p[1] + p[2]

def p_statement(p):
    '''statement : assignment_statement
                 | print_statement
                 | this_assign
                 | return'''
    p[0] = p[1]

def p_return(p):
    '''return : RETURN IDENTIFIER SEMICOLON'''
    p[0] = p[1] + p[2] + p[3]

def p_this_assign(p):
    '''this_assign : THIS IDENTIFIER ASSIGN IDENTIFIER SEMICOLON'''
    p[0] = 'this.' + p[2] + '=' + p[4] + ';'

def p_assignment_statement(p):
    '''assignment_statement : RETURNTYPE IDENTIFIER ASSIGN expression SEMICOLON
                            | RETURNTYPE IDENTIFIER SEMICOLON
                            | IDENTIFIER ASSIGN expression SEMICOLON'''
    if len(p) == 6:
        p[0] = p[1] + p[2] + '=' + p[4] + ';'
    elif len(p) == 4:
        p[0] = p[1] + p[2] + ';'
    else:
        p[0] = p[1] + '=' + p[3] + ';'

def p_print_statement(p):
    '''print_statement : SOP LPAREN expression RPAREN SEMICOLON'''
    p[0] = 'System.out.println(' + p[3] + ');'

def p_expression(p):
    '''expression : IDENTIFIER
                  | NUMBER
                  | expression PLUS expression
                  | expression MINUS expression
                  | expression TIMES expression
                  | expression DIVIDE expression
                  | DQUOTE sentences DQUOTE'''
    if len(p) == 2:
        p[0] = p[1]
    elif len(p) == 4:
        if p[1] == '"':
            p[0] = '"' + p[2] + '"'
        else:
            p[0] = p[1] + p[2] + p[3]

def p_sentences(p):
    '''sentences : sentence
                 | sentence sentences'''
    if len(p)==2:
        p[0] = p[1]
    else:
        p[0] = p[1] + p[2]

def p_sentence(p):
    '''sentence :  IDENTIFIER
                  | NUMBER
                  | sentence PLUS
                  | sentence MINUS
                  | sentence PLUS sentence
                  | sentence MINUS sentence
                  | sentence TIMES sentence
                  | sentence DIVIDE sentence'''
    if len(p) == 2:
        p[0] = p[1]
    elif len(p) == 3:
        p[0] = p[1] + p[2]
    else:
        p[0] = p[1] + p[2] + p[3]

def p_error(p):
    print("Syntax error at '%s'" % p.value)

parser = yacc.yacc()

while True:
    try:
        s = input('calc > ')
    except EOFError:
        break
    if not s: continue
    result = parser.parse(s)
    if result is None:
        print("Error")
    else:
        print("Valid statement")

# public class Car{  private String brand; private int year; private double price; public Car(String brand, int year, double price) { this.brand = brand; this.year = year; this.price = price; } public String getBrand() { return brand; } public int getYear() { return year; } public double getPrice() { return price; } public void setPrice(double price) { this.price = price; } }