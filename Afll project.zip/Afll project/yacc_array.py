import ply.yacc as yacc

from lex_array import tokens

def p_function(p):
    '''array : TYPE LPAREN RPAREN IDENTIFIER ASSIGN LBRACE statements RBRACE SEMICOLON'''
    p[0] = p[1]  +'[' + ']'  + ' ' + p[4] + ' = {' + p[7] + '};'


def p_statements(p):
    '''statements : statement
                  | statement COMMA statements'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = p[1] + ', ' + p[3]

def p_statement(p):
    '''statement : NUMBER
                 | CHAR'''
    p[0] = p[1]

def p_error(p):
    print("Syntax error at '%s'" % p.value)

parser = yacc.yacc()

while True:
    try:
        s = input('calc > ')
    except EOFError:
        break
    if not s: continue
    result = parser.parse(s)
    if result is None:
        print("Error")
    else:
        print("Valid statement")
