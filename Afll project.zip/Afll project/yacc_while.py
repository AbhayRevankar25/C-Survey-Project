import ply.yacc as yacc

from lex_while import tokens

def p_function(p):
    '''while : WHILE LPAREN parameters RPAREN LBRACE statements RBRACE'''
    p[0] = 'while' + '(' + p[3] + ')' + '{' + p[6] +'}'
    pass

def p_parameters(p):
    '''parameters : parameter
                  | parameter LOGICAL parameters'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = p[1] + p[2] + p[3]

def p_parameter(p):
    '''parameter : IDENTIFIER
                 | NUMBER'''
    p[0] = p[1]

def p_statements(p):
    '''statements : statement
                  | statement statements'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = p[1] + p[2]

def p_statement(p):
    '''statement : assignment_statement
                 | print_statement'''
    p[0] = p[1]

def p_assignment_statement(p):
    '''assignment_statement : RETURNTYPE IDENTIFIER ASSIGN expression SEMICOLON
                            | RETURNTYPE IDENTIFIER SEMICOLON
                            | IDENTIFIER ASSIGN expression SEMICOLON'''
    if len(p) == 6:
        p[0] = p[1] + p[2] + '=' + p[4] + ';'
    elif len(p) == 4:
        p[0] = p[1] + p[2] + ';'
    else:
        p[0] = p[1] + '=' + p[3] + ';'

def p_print_statement(p):
    '''print_statement : SOP LPAREN expression RPAREN SEMICOLON'''
    p[0] = 'System.out.println(' + p[3] + ');'

def p_expression(p):
    '''expression : IDENTIFIER
                  | NUMBER
                  | expression PLUS
                  | expression MINUS
                  | expression PLUS expression
                  | expression MINUS expression
                  | expression TIMES expression
                  | expression DIVIDE expression
                  | DQUOTE sentences DQUOTE'''
    if len(p) == 2:
        p[0] = p[1]
    elif len(p) == 3:
        p[0] = p[1] + p[2]
    elif len(p) == 4:
        if p[1] == '"':
            p[0] = '"' + p[2] + '"'
        else:
            p[0] = p[1] + p[2] + p[3]

def p_sentences(p):
    '''sentences : sentence
                 | sentence sentences'''
    if len(p)==2:
        p[0] = p[1]
    else:
        p[0] = p[1] + p[2]

def p_sentence(p):
    '''sentence :  IDENTIFIER
                  | NUMBER
                  | sentence PLUS
                  | sentence MINUS
                  | sentence PLUS sentence
                  | sentence MINUS sentence
                  | sentence TIMES sentence
                  | sentence DIVIDE sentence'''
    if len(p) == 2:
        p[0] = p[1]
    elif len(p) == 3:
        p[0] = p[1] + p[2]
    else:
        p[0] = p[1] + p[2] + p[3]

def p_error(p):
    print("Syntax error at '%s'" % p.value)

parser = yacc.yacc()

while True:
    try:
        s = input('calc > ')
    except EOFError:
        break
    if not s: continue
    result = parser.parse(s)
    if result is None:
        print("Error")
    else:
        print("Valid statement")

# while(i>=8 && i<=12){System.out.println("Hello"); i=i+1;}